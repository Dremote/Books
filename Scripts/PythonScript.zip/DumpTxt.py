import sys
import getopt

class TxtParseFile:
	def __init__(self, TxtFile):
		self._TxtFile = TxtFile
		self._DUT1Data = []
		self._DUT2Data = []
		self._DUT3Data = []
	
	def DumpDataFromFile(self):
		#Save TxtFile contents in a list => Data
		with open(self._TxtFile,"r",encoding="utf-8") as FileData:
			DataLine = FileData.readlines()
			
		#Initialization
		DUT1 = []
		DUT2 = []
		DUT3 = []
			
		#Acquire valid data
		for Index in range(0,len(DataLine)):
			if DataLine[Index][:4].upper() == "DUT1":
				DUT1.append(DataLine[Index])
			elif DataLine[Index][:4].upper() == "DUT2":
				DUT2.append(DataLine[Index])
			elif DataLine[Index][:4].upper() == "DUT3":
				DUT3.append(DataLine[Index])
			else:
				continue
				
		DUT1DumpFile = "DUT1Log.txt"
		DUT2DumpFile = "DUT2Log.txt"
		DUT3DumpFile = "DUT3Log.txt"
		
		OutputFile1 = open(DUT1DumpFile, 'w')
		OutputFile1.writelines(DUT1)
		OutputFile1.close()
		
		
		OutputFile2 = open(DUT2DumpFile, 'w')
		OutputFile2.writelines(DUT2)
		OutputFile2.close()		
		
		OutputFile3 = open(DUT3DumpFile, 'w')
		OutputFile3.writelines(DUT3)
		OutputFile3.close()	
		
		return 0
		
def Usage():
	print("################################")
	print("#          Version: 1.00       #")
	print("################################")
	print("Example: DumpTxt.exe -i *.txt")
	print("Input_file Format: TXT")


def Main(argv=None):
	if argv is None:
		argv = sys.argv
	
	InputFile = ""

	try:
		opts, args = getopt.getopt(sys.argv[1:], "hi:", ["help"])
		if opts == []:
			Usage()
			return 1
		else:
			for op, val in opts:
				if op in ("-h", "--help"):
					Usage()
					return 1
				elif op in ("-i"):
					InputFile = val

	except:
		print("ERROR:Invalid parameter!")
		return 1
	
	FileParse = TxtParseFile(InputFile)
	
	ReturnValue = FileParse.DumpDataFromFile()
	return 0
	
if __name__ == '__main__':
	sys.exit(Main())	
